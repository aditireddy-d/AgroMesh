#define mySSID ""
#define myPASS ""